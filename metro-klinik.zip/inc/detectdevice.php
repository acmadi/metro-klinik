<?php
/*Device detection */
include_once('inc/mobile_device.php');

if($enableMobile){
	/*only in full version */
}
$mobile = false;
?>