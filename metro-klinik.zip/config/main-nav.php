<a rel="group0" id="menu1">
	<img src="img/icons/transaksi2.png" alt="home"/>
	Transaksi
</a>
<a rel="group1">
	<img src="img/icons/masterdata2.png" alt="Master Data"/>
	Master Data
 </a>
<a rel="group2">
	<img src="img/icons/laporan2.png" alt="Laporan"/>
	Laporan
</a>

<a rel="group3" onclick="location.href='pages/logout.php'">
        <img src="img/icons/logout.png" alt="Logout" align="center"/>
        Logout
</a>